package com.android.launcher3;

import android.app.Activity;

public class ToggleWeightWatcher extends Activity {

}
